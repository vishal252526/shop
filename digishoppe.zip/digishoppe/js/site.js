$(document).ready(function(){
	jQuery.scrollSpeed(100, 800);
	
	$(document).on("scroll", function(e) {
	  if ($(this).scrollTop() > 147) {
		$('.navbar').addClass("fix_header");
		$('.go_top').show();
	  } else {
		$('.navbar').removeClass("fix_header");
		$('.go_top').hide();
	  }	  
	});
	
	$('.go_top').on('click', function(){
		$("html, body").animate({scrollTop: "0px"}, "slow");
	});
	
	$('#product_tabs a').on('click', function (e) {
	  e.preventDefault()
	  $(this).tab('show')
	});
	
	$('[data-toggle="tooltip"]').tooltip();
	
	$('div[data-link], span[data-link]').on('click', function(e){
		location.href = $(this).attr('data-link');
	});
	
	if($('.mobile_container').length){
		$('.toolset span').on('click', function(e){
			e.stopPropagation();
		});
	}
	
	if($('.variant').length || $('.plan_box').length){
		$('.variant, .plan_box').on('click', function(){
			$(this).addClass('selected').siblings().removeClass('selected');
		});
	}
	
	if($('.progress_indicator').length){
		$('.steps.visited').on('click', function(){
			location.href = $(this).attr('data-link');
		});
	}
	
	if($('.qty_control').length){
		$('.qty_control .i_subtract').on('click', function(){
			var $currInput = $(this).parent().parent().find('.input_qty');
			if(parseInt($currInput.val()) > 0){
				$currInput.val(parseInt($currInput.val())-1);
			}
		});
		$('.qty_control .i_addQty').on('click', function(){
			var $currInput = $(this).parent().parent().find('.input_qty');
			$currInput.val(parseInt($currInput.val())+1);
		});
	}
	
	/*$('.i_user').on('mouseenter',function(e){
		e.preventDefault();
		$('.nav_drop').slideUp();
		if(!($(this).hasClass('loggedin'))){
			var timer;
			$('.login_drop').slideDown().on('mouseleave', function(){
				timer = setTimeout(function(){$('.login_drop').slideUp()}, 500);
				$('.login_drop').on('mouseenter', function(){
					clearTimeout(timer);
				});				
			});
		}
	});*/
	
	$('.has_drop').on('mouseenter',function(e){
		e.preventDefault();
		$('.nav_drop, .sec_nav_drop').slideUp();
		var timer;
		var $drop = $(this).next();  
		$drop.slideDown().on('mouseleave', function(){
			timer = setTimeout(function(){$drop.slideUp()}, 500);
			$drop.on('mouseenter', function(){
				clearTimeout(timer);
			});				
		});
	});
	/*help me choose Script*/
	if($('#help_me_choose').length){		
		$('#selecctall').on('click', function(event) { 
			if(this.checked) {
				$(this).parent().addClass('selected ');
				$('.check1').each(function() { 
					this.checked = true; 
					$(this).parent().addClass('selected ');
				});
			}else{
				$(this).parent().removeClass('selected ');
				$('.check1').each(function() {
					this.checked = false;
					$(this).parent().removeClass('selected ');
				});         
			}
		});
		$('.check1, .check2').on('click', function(event) { 
			if(this.checked) {
				$(this).parent().addClass('selected ');				
			}else{
				$(this).parent().removeClass('selected ');
			}
		});
		$('#selecctall2').on('click', function(event) { 
			if(this.checked) {
				$(this).parent().addClass('selected ');
				$('.check2').each(function() { 
					this.checked = true; 
					$(this).parent().addClass('selected ');
				});
			}else{
				$(this).parent().removeClass('selected ');
				$('.check2').each(function() {
					this.checked = false;
					$(this).parent().removeClass('selected ');
				});         
			}
		});
		$('#next_step').on('click', function(event) { 
			$('#device').slideUp('slow');
			$('#purpose').slideDown('slow');
			$('.progress_indicator2 .step2').addClass('active');
		});
		$('#back_devices').on('click', function(event) { 
			$('#purpose').slideUp('slow');
			$('#device').slideDown('slow');
			$('.progress_indicator2 .step2').removeClass('active');
		});
		$('#next_final').on('click', function(event) { 
			$('#purpose').slideUp('slow');
			$('#plan').slideDown('slow');
			$('.progress_indicator2 .step3').addClass('active');
		});
		$('.start_again').on('click', function(event) { 
			$('#purpose, #plan').slideUp('slow');
			$('#device').slideDown('slow');
			$('.progress_indicator2 .step2').removeClass('active');
			$('.progress_indicator2 .step3').removeClass('active');
			$('.check1, .check2, #selecctall, #selecctall2').each(function() {
				this.checked = false;
				$(this).parent().removeClass('selected ');
			});
		});
		$('.plan_details').on('click', function(event) { 
			$(this).addClass('focus').siblings().removeClass('focus');
		});
	}
	
	/*Junk code for the prototype, need to be removed once back-end code is implemented*/
	if($('.mobile_container').length){
		$('.i_cart2').on('click', function(){
			if(!($(this).hasClass('selected'))){
				$(this).addClass('selected');
				if(typeof(Storage) !== "undefined") {
					if(localStorage.getItem("cartCount") == null){ 
						localStorage.setItem("cartCount", 1);
						$('.i_cart').append('<sup>1</sup>');
					}else{
						var cartCount = parseInt(localStorage.getItem("cartCount"))+1;
						localStorage.setItem("cartCount", cartCount);
					}
					$('.i_cart sup').html(cartCount);
					$('.cart_count').html(cartCount);
				}
			}
		});
	}
	
	if(typeof(Storage) !== "undefined") {
		if(localStorage.getItem("cartCount") == null){
		}else{
			var cartCount = parseInt(localStorage.getItem("cartCount"));
			if($('.i_cart sup').length < 1){ 
				$('.i_cart').append('<sup>'+0+'</sup>');
				$('.cart_count').html(cartCount);
			}else{
				$('.i_cart sup').html(cartCount);
				$('.cart_count').html(cartCount);
			}
		}		
	}	

	$('.cart_table').ready(function(){
		if(typeof(Storage) !== "undefined") {
			var cartCount = parseInt(localStorage.getItem("cartCount"));
			for(i=1; i< cartCount; i++){
				$('.cart_table tr:last-child').clone().appendTo('.cart_table');
			}
		}
		$('.i_remove').on('click', function(){
			$(this).parent().parent().remove();
			if(typeof(Storage) !== "undefined") {
				var cartCount = parseInt(localStorage.getItem("cartCount"))-1;
				$('.i_cart sup').html(cartCount);	
				localStorage.setItem("cartCount", cartCount);				
			}
		});
	});
});
